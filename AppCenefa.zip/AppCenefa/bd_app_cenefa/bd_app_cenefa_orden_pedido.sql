-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: bd_app_cenefa
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orden_pedido`
--

DROP TABLE IF EXISTS `orden_pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orden_pedido` (
  `id_op` int NOT NULL AUTO_INCREMENT,
  `prefijo_op` varchar(4) NOT NULL,
  `serie_op` int DEFAULT '0',
  `prefijo_fact` varchar(5) DEFAULT NULL,
  `serie_fact` int DEFAULT NULL,
  `cc_nit_op` varchar(15) NOT NULL,
  `referencia_art_op` int NOT NULL,
  `nombre_art_op` varchar(50) NOT NULL,
  `cantidad_art_op` double NOT NULL,
  `total_cantidad_art_op` double DEFAULT NULL,
  `costo_art_op` double NOT NULL,
  `subtotal_art_op` double NOT NULL,
  PRIMARY KEY (`id_op`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orden_pedido`
--

LOCK TABLES `orden_pedido` WRITE;
/*!40000 ALTER TABLE `orden_pedido` DISABLE KEYS */;
INSERT INTO `orden_pedido` VALUES (1,'OP',1,'FC',1,'1234567890',1,'Piso opera blanco (55 x 55)',150,150,25000,3750000),(2,'OP',1,'FC',1,'1234567890',3,'Pegante ceramico gris Pegacor',234,234,18000,4212000),(3,'OP',1,'FC',1,'1234567890',4,'Boquilla fina Concolor',456,456,7000,3192000),(4,'OP',1,'FC',1,'1234567890',5,'Piso riveria beige (60 x 60)',124,124,28000,3472000),(5,'OP',1,'FC',1,'1234567890',6,'Piso laika beige (60 x 60)',678,678,25678,17409684),(6,'OP',1,'FC',1,'1234567890',7,'Piso sibila blanco (60 x 60)',234,234,29753,6962202),(7,'OP',1,'FC',1,'1234567890',8,'Piso prato gris (60 x 60)',234,234,23456,5488704),(8,'OP',8,'FC',2,'0987654321',2,'Pared tobago gris',234,234,23456,5488704),(9,'OP',8,'FC',2,'0987654321',9,'Pared atenas marfil (32.3 x 56)',345,345,27546,9503370),(10,'OP',8,'FC',2,'0987654321',10,'Pared curazao gris (32 x 56)',654,654,27542,18012468),(11,'OP',11,'FC',3,'6789054321',11,'Pared zafiro (45 x 90)',456,456,28656,13067136),(12,'OP',11,'FC',3,'6789054321',12,'Pared cuarzo blanco (45 x 90)',678,678,25345,17183910),(13,'OP',13,'FC',4,'5432167890',13,'Pegante ceramico gris Alfaquick',234,234,23455,5488470),(14,'OP',13,'FC',4,'5432167890',14,'Boquilla fina Alfaquick',50,50,5000,250000),(15,'OP',15,'FC',5,'123987534',15,'Cemento Argos',150,150,18000,2700000);
/*!40000 ALTER TABLE `orden_pedido` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-19  0:44:14
